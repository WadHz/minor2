# minor2
minor2 opdracht
